import cgi
import cgitb
import json
import boto3
from botocore.exceptions import ClientError

cgitb.enable()  # Enable debugging for CGI scripts

def handle_request():
    print("Content-Type: application/json")
    print()  # End of headers

    form = cgi.FieldStorage()
    region = form.getfirst('region')                                                              #HERE you have give an specific region
    aws_access_key_id = form.getfirst('aws_access_key_id')                                    # Here you have to put your Key id

    aws_secret_access_key = form.getfirst('aws_secret_access_key')                          #Here you have to put your AWS secret key
    instance_type = form.getfirst('instance_type')
    image_id = form.getfirst('image_id')

    if not all([region, aws_access_key_id, aws_secret_access_key, instance_type, image_id]):
        response = {"error": "All fields are required"}
        print(json.dumps(response))
        return

    try:
        ec2 = boto3.resource(
            'ec2',
            region_name=region,
            aws_access_key_id=aws_access_key_id,                               # Here you have to put your Key id

            aws_secret_access_key=aws_secret_access_key                      #Here you have to put your AWS secret key
        )
        instances = ec2.create_instances(
            InstanceType=instance_type,
            ImageId=image_id,
            MinCount=1,
            MaxCount=1
        )
        instance_id = instances[0].id
        response = {"success": f"Instance created successfully! Instance ID: {instance_id}"}                 # it will cshow your instance id as it will launch
    except ClientError as error:
        response = {"error": str(error)}

    print(json.dumps(response))

if __name__ == "__main__":
    handle_request()
