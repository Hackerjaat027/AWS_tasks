.,ṁort cgi
import boto3
import json
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

# AWS credentials (use environment variables, IAM roles, or config files in production)
AWS_ACCESS_KEY_ID = 'your_key'                                  # Here you have to put your Key id

AWS_SECRET_ACCESS_KEY = 'your_secret_key'                     #Here you have to put your AWS secret key

# Function to fetch CloudWatch logs
def fetch_logs(log_group, log_stream, region):
    try:
        client = boto3.client('logs',
                              aws_access_key_id=AWS_ACCESS_KEY_ID,                            # Here you have to put your Key id
                              aws_secret_access_key=AWS_SECRET_ACCESS_KEY,                    #Here you have to put your AWS secret key
                              region_name=region)

        response = client.get_log_events(
            logGroupName=log_group,
            logStreamName=log_stream,
            limit=10  # Number of log events to fetch
        )

        return [{'timestamp': event['timestamp'], 'message': event['message']} for event in response.get('events', [])]

    except (NoCredentialsError, PartialCredentialsError) as cred_error:
        return {'error': 'Credentials are incorrect or not provided: ' + str(cred_error)}
    except Exception as e:
        return {'error': 'An error occurred: ' + str(e)}

# Main CGI script handling
def main():
    print("Content-Type: application/json")
    print()  # End of headers

    form = cgi.FieldStorage()
    log_group = form.getvalue('log_group')
    log_stream = form.getvalue('log_stream')
    region = form.getvalue('region')

    if not all([log_group, log_stream, region]):
        print(json.dumps({'error': 'Please provide log_group, log_stream, and region parameters'}))
        return

    logs = fetch_logs(log_group, log_stream, region)
    print(json.dumps(logs))

if __name__ == '__main__':
    main()
