import pymongo
import json

def lambda_handler(event, context):
                                                    # MongoDB connection details
    mongo_uri = "mongodb://username:password@your-mongodb-host:27.01.24/your-database"           # Here you have to put your username,password and your host ip with your data base name 
    
    # Establishing the connection to MongoDB
    with pymongo.MongoClient(mongo_uri) as client:
        db = client['your-database']                                   #you have to give your database name (in my case it's NIK_test1) 
        collection = db['your-collection']                             #in this you have give name of your collection 

        # Example query
        result = collection.find_one({"key": "value"})

    # Formatting the result for JSON response
    response = json.dumps(result, default=str)                           # Use default=str to handle ObjectId or datetime objects

    return {
        'statusCode': 200,
        'body': response
    }
