import boto3

def create_aws_session():
    return boto3.Session(
        aws_access_key_id='your_access_key_id',        # Replace with your AWS Access Key
        aws_secret_access_key='your_secret_access_key',# Replace with your AWS Secret Key
        region_name='your_region'                      # Replace with your AWS region (e.g., 'us-west-2')
    )

def start_rhel_gui_instance(session):
    ec2 = session.client('ec2')

    ami_id = 'your_ami_id'  # Replace with the appropriate RHEL AMI ID that supports GUI in your region
    instance_type = 't2.large'  # Specify an instance type that supports GUI (in my case i choose t2.large)
    key_name = 'your_key_pair_name'  # Replace with your key pair name

    try:
        instances = ec2.run_instances(
            ImageId=ami_id,
            InstanceType=instance_type,
            KeyName=key_name,
            MinCount=1,
            MaxCount=1,
            TagSpecifications=[
                {
                    'ResourceType': 'instance',
                    'Tags': [
                        {'Key': 'Name', 'Value': 'RHEL-GUI-Instance'},
                    ]
                },
            ]
        )

        instance_id = instances['Instances'][0]['InstanceId']
        print(f"Launched RHEL GUI instance with ID: {instance_id}")

        # Wait until the instance is running
        ec2.get_waiter('instance_running').wait(InstanceIds=[instance_id])
        print(f"Instance {instance_id} is now running.")

    except Exception as err:
        print(f"Error launching RHEL GUI instance: {err}")

def main():
    session = create_aws_session()
    start_rhel_gui_instance(session)

if __name__ == "__main__":
    main()
