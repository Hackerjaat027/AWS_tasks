#!/usr/bin/env python
import cgi
import boto3
import cgitb

# Enable debugging for CGI scripts
cgitb.enable()

print("Content-Type: text/html\r\n\r\n")

def main():
    form = cgi.FieldStorage()

    # Replace these with your AWS credentials and region
    region = 'your-region'
    aws_access_key = 'your-access-key'
    aws_secret_key = 'your-secret-key'

    # Validate and retrieve form inputs
    if 'file' not in form or 'bucketName' not in form:
        print("Error: Missing form data (file or bucketName).")
        return

    file_item = form['file']
    bucket_name = form.getvalue('bucketName')

    if not file_item.file or not bucket_name:
        print("Error: No file or bucket name provided.")
        return

    # Initialize S3 client
    s3 = boto3.client('s3', region_name=region, aws_access_key_id=aws_access_key, aws_secret_access_key=aws_secret_key)

    try:
        # Upload file to S3
        s3.upload_fileobj(file_item.file, bucket_name, file_item.filename)
        print(f"Successfully uploaded '{file_item.filename}' to bucket '{bucket_name}'.")
    except Exception as err:
        print(f"Error during upload: {err}")

if __name__ == "__main__":
    main()
