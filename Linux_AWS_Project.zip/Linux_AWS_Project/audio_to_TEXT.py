import json
import boto3
import logging

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def lambda_handler(event, context):
    logger.info("Received event: %s", json.dumps(event, indent=2))  # Pretty print the incoming event

    s3 = boto3.client('s3')
    transcribe = boto3.client('transcribe')

    try:
        record = event['Records'][0]
        bucket_name = record['s3']['bucket']['name']
        file_key = record['s3']['object']['key']
        logger.info(f"Processing file: {file_key} from bucket: {bucket_name}")

        job_name = f"TranscriptionJob-{file_key.split('/')[-1].split('.')[0]}"
        file_uri = f"s3://{bucket_name}/{file_key}"

        response = transcribe.start_transcription_job(
            TranscriptionJobName=job_name,
            Media={'MediaFileUri': file_uri},
            MediaFormat=file_key.rsplit('.', 1)[-1],  # Extract file extension
            LanguageCode='en-US'  # Adjust this for the appropriate language
        )
        logger.info(f"Transcription job started successfully: {json.dumps(response, indent=2)}")

        return {
            'statusCode': 200,
            'body': json.dumps({'message': f"Started transcription job: {job_name}"})
        }

    except Exception as err:
        logger.error("An error occurred: %s", str(err))
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(err)})
        }
