import boto3
import logging

# Set up logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Initialize AWS clients
REGION = 'us-east-1'  # Specify your AWS region
s3 = boto3.client('s3', region_name=REGION)
ses = boto3.client('ses', region_name=REGION)

# Define constants
S3_BUCKET = 'kun-demo-bucket'  # Replace with your S3 bucket name
S3_KEY = 'hello.txt'  # The S3 file containing email IDs
SES_SENDER = 'subdomain.example.com'  # Replace with your verified SES email address

def lambda_handler(event, context):
    # Step 1: Fetch the email list from S3
    email_list = fetch_emails_from_s3(S3_BUCKET, S3_KEY)

    if not email_list:
        return {
            'statusCode': 500,
            'body': 'Failed to retrieve email IDs from S3.'
        }

    # Step 2: Send emails using SES
    for email in email_list:
        send_email_via_ses(email)

    return {
        'statusCode': 200,
        'body': 'Emails have been sent successfully.'
    }

def fetch_emails_from_s3(bucket, key):
    """Fetches email IDs from an S3 object."""
    try:
        obj = s3.get_object(Bucket=bucket, Key=key)
        content = obj['Body'].read().decode('utf-8')
        emails = content.splitlines()
        logger.info(f"Successfully retrieved email IDs: {emails}")
        return emails
    except Exception as err:
        logger.error(f"Error retrieving file from S3: {err}")
        return None

def send_email_via_ses(recipient):
    """Sends an email using SES."""
    try:
        response = ses.send_email(
            Source=SES_SENDER,
            Destination={'ToAddresses': [recipient]},
            Message={
                'Subject': {'Data': 'Greetings from AWS Lambda and SES', 'Charset': 'UTF-8'},
                'Body': {
                    'Text': {
                        'Data': 'This is a test email sent from an AWS Lambda function.',
                        'Charset': 'UTF-8'
                    }
                }
            }
        )
        logger.info(f"Email sent to {recipient}: Message ID {response['MessageId']}")
    except Exception as err:
        logger.error(f"Failed to send email to {recipient}: {err}")

# Uncomment the following lines for local testing
# if __name__ == "__main__":
#     lambda_handler(None, None)
